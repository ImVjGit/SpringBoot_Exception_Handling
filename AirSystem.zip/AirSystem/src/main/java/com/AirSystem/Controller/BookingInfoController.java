package com.AirSystem.Controller;

import com.AirSystem.Entity.*;
import com.AirSystem.Service.BookingInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.AirSystem.Service.*;
import springfox.documentation.spi.service.contexts.RequestMappingContext;

import java.text.ParseException;

@RestController
//@RequestMapping(RequestMappinConstants.BOOKINGINFO)
@CrossOrigin
public class BookingInfoController {
    @Autowired
    private BookingInfoService bookingInfoService;

    @Autowired
    private CustomerService customerService;


    @PutMapping("/Booking/{id}")
    public String SaveBooking(@PathVariable("id") Long id,
                              @RequestBody BookingInfo bookingInfo) throws ParseException {
//       long id1 = customerService.getCustomerbyId(id).getCustomerId();
//        if()
        System.out.println("id Is :"+bookingInfo.getCustomerName());
        String rs = bookingInfoService.saveBookInfo(id, bookingInfo);
        if (rs.equalsIgnoreCase("Found")) {
            return "Booking Created";
        }


        return "invalid id plz Check the id ";
    }
}
